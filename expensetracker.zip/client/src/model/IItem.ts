interface IItem {
    id:number,
        payeeName: string,
        product: string,
        price: number,
        setDate: string,
}
export default IItem