
import ExpenseTracker  from './component/ExpenseTracker';
import 'bootstrap/dist/css/bootstrap.min.css'
function App() {
  return (
    <div >
      <ExpenseTracker/>
    </div>
  );
}

export default App;
